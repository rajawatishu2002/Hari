<template>
  <LoginForm />
</template>

<script>
import LoginForm from "@/components/LoginForm.vue";
export default {
  layout: "login",
  components: {
    LoginForm
  }
};
</script>

<style>
</style>
