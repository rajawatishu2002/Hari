package io.snyk.snyklabs.message;

public enum MessageTypes {
    MESSAGE, JOIN, LEAVE;
}
