package io.snyk.snyklabs.app;

public enum AppError {
    INVALID_ROOM_KEY;
}
